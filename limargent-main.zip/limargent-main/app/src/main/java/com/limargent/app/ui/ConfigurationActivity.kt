package com.limargent.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.limargent.app.R
import com.limargent.app.adapter.CategoryAdapter
import com.limargent.app.firebase.FirebaseManager
import com.limargent.app.manager.BudgetManager
import com.limargent.app.model.Category
import com.limargent.app.model.MoneyMovement
import com.limargent.app.model.SavingsGoal
import com.limargent.app.utils.StringUtils
import java.text.NumberFormat
import java.util.*

class ConfigurationActivity : AppCompatActivity(), BudgetManager.BudgetUpdateListener {

    private lateinit var recyclerView: RecyclerView
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var adapter: CategoryAdapter

    private lateinit var switchAlerte: Switch
    private lateinit var etSeuilMontant: TextInputEditText
    private lateinit var btnSaveAlerte: MaterialButton

    private lateinit var containerGoals: LinearLayout
    private lateinit var tvNoGoals: TextView
    private lateinit var btnAddObjectif: MaterialButton

    private lateinit var containerRecurrents: LinearLayout
    private lateinit var tvNoRecurrence: TextView

    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale.FRANCE)

    private val predefinedColors = listOf(
        "#FF6384", "#36A2EB", "#FFCE56", "#4BC0C0",
        "#9966FF", "#FF9F40", "#7BC8A4", "#FF6B6B",
        "#48DBFB", "#FFA502", "#2ED573", "#FF4757"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_configuration)

        initViews()
        setupAlerte()
        setupSavingsGoals()
        setupRecyclerView()
        setupBottomNavigation()

        BudgetManager.addListener(this)

        FirebaseManager.chargerParametresAlerte()
        FirebaseManager.startListeningSavingsGoals()

        updateDisplay()
    }

    private fun initViews() {
        recyclerView = findViewById(R.id.recyclerViewCategories)
        bottomNav = findViewById(R.id.bottomNavigation)

        switchAlerte = findViewById(R.id.switchAlerte)
        etSeuilMontant = findViewById(R.id.etSeuilMontant)
        btnSaveAlerte = findViewById(R.id.btnSaveAlerte)

        containerGoals = findViewById(R.id.containerGoals)
        tvNoGoals = findViewById(R.id.tvNoGoals)
        btnAddObjectif = findViewById(R.id.btnAddObjectif)

        containerRecurrents = findViewById(R.id.containerRecurrents)
        tvNoRecurrence = findViewById(R.id.tvNoRecurrence)

        findViewById<MaterialButton>(R.id.btnAddCategory).setOnClickListener {
            showAddCategoryDialog()
        }
    }

    private fun setupAlerte() {
        switchAlerte.isChecked = BudgetManager.alerteActivee
        if (BudgetManager.seuilAlerte != -500.0) {
            etSeuilMontant.setText(String.format("%.2f", BudgetManager.seuilAlerte))
        }

        btnSaveAlerte.setOnClickListener {
            val montantStr = etSeuilMontant.text.toString().trim()
            val seuil = montantStr.toDoubleOrNull()

            if (seuil == null) {
                Toast.makeText(this, "Veuillez entrer un montant valide", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val active = switchAlerte.isChecked
            BudgetManager.configurerAlerte(seuil, active)

            FirebaseManager.sauvegarderParametresAlerte(seuil, active,
                onSuccess = {
                    Toast.makeText(this, "Seuil d'alerte sauvegarde", Toast.LENGTH_SHORT).show()
                },
                onError = { error ->
                    Toast.makeText(this, error, Toast.LENGTH_SHORT).show()
                }
            )
        }
    }

    private fun setupSavingsGoals() {
        btnAddObjectif.setOnClickListener {
            showAddGoalDialog()
        }
    }

    private fun showAddGoalDialog() {
        val dialogView = LayoutInflater.from(this)
            .inflate(R.layout.dialog_add_category, null)

        val etNom = dialogView.findViewById<EditText>(R.id.etCategoryNom)
        val etIcon = dialogView.findViewById<EditText>(R.id.etCategoryIcon)

        etNom.hint = "Nom de l'objectif (ex: Vacances)"
        etIcon.setText("*")
        etIcon.hint = "Icone"

        val etMontant = EditText(this).apply {
            hint = "Montant cible (EUR)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setTextColor(resources.getColor(R.color.text_primary, theme))
            setHintTextColor(resources.getColor(R.color.text_secondary, theme))
        }

        val container = dialogView as LinearLayout
        container.addView(etMontant)

        MaterialAlertDialogBuilder(this)
            .setTitle("Nouvel objectif d'epargne")
            .setView(dialogView)
            .setPositiveButton("Creer") { _, _ ->
                val nom = etNom.text.toString().trim()
                val icon = StringUtils.filterEmojis(etIcon.text.toString().trim().ifEmpty { "*" })
                val montant = etMontant.text.toString().toDoubleOrNull()

                if (nom.isEmpty()) {
                    Toast.makeText(this, "Veuillez saisir un nom", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (montant == null || montant <= 0) {
                    Toast.makeText(this, "Montant cible invalide", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val goal = SavingsGoal(
                    nom = nom,
                    montantCible = montant,
                    montantActuel = 0.0,
                    icone = icon,
                    userId = FirebaseManager.getCurrentUser()?.uid ?: ""
                )

                BudgetManager.ajouterObjectif(goal)
                FirebaseManager.ajouterObjectif(goal,
                    onSuccess = {
                        runOnUiThread {
                            Toast.makeText(this, "Objectif cree", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
                updateGoalsDisplay()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun showAddMontantDialog(goal: SavingsGoal) {
        val input = EditText(this).apply {
            hint = "Montant a ajouter (EUR)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setTextColor(resources.getColor(R.color.text_primary, theme))
            setHintTextColor(resources.getColor(R.color.text_secondary, theme))
            setPadding(48, 32, 48, 32)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Ajouter a \"${goal.nom}\"")
            .setMessage("Montant actuel: ${currencyFormat.format(goal.montantActuel)} / ${currencyFormat.format(goal.montantCible)}")
            .setView(input)
            .setPositiveButton("Ajouter") { _, _ ->
                val montant = input.text.toString().toDoubleOrNull()
                if (montant != null && montant > 0) {
                    goal.montantActuel += montant
                    BudgetManager.mettreAJourObjectif(goal)
                    FirebaseManager.mettreAJourObjectif(goal)

                    val mouvement = MoneyMovement(
                        titre = "Epargne: ${goal.nom}",
                        montant = -montant,
                        categorie = "Epargne",
                        date = java.util.Date(),
                        userId = FirebaseManager.getCurrentUser()?.uid ?: ""
                    )
                    BudgetManager.ajouterMouvement(mouvement)
                    FirebaseManager.ajouterMouvement(mouvement)

                    if (goal.isAtteint()) {
                        Toast.makeText(this, "Objectif \"${goal.nom}\" atteint !", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, "${currencyFormat.format(montant)} epargne", Toast.LENGTH_SHORT).show()
                    }
                    updateGoalsDisplay()
                }
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun updateGoalsDisplay() {
        containerGoals.removeAllViews()
        val goals = BudgetManager.savingsGoals

        if (goals.isEmpty()) {
            tvNoGoals.visibility = View.VISIBLE
            return
        }

        tvNoGoals.visibility = View.GONE

        for (goal in goals) {
            val itemView = LayoutInflater.from(this)
                .inflate(R.layout.item_savings_goal, containerGoals, false)

            itemView.findViewById<TextView>(R.id.tvGoalIcon).text = StringUtils.filterEmojis(goal.icone)
            itemView.findViewById<TextView>(R.id.tvGoalNom).text = goal.nom
            itemView.findViewById<TextView>(R.id.tvGoalMontants).text =
                "${currencyFormat.format(goal.montantActuel)} / ${currencyFormat.format(goal.montantCible)}"

            val progressBar = itemView.findViewById<ProgressBar>(R.id.progressGoal)
            progressBar.progress = goal.progression()

            val tvPct = itemView.findViewById<TextView>(R.id.tvGoalPourcentage)
            tvPct.text = "${goal.progression()}%"

            val tvStatus = itemView.findViewById<TextView>(R.id.tvGoalStatus)
            if (goal.isAtteint()) {
                tvStatus.text = "Atteint !"
                tvStatus.setTextColor(resources.getColor(R.color.income_green, theme))
                tvPct.setTextColor(resources.getColor(R.color.income_green, theme))
            } else {
                tvStatus.text = "Reste: ${currencyFormat.format(goal.montantRestant())}"
                tvStatus.setTextColor(resources.getColor(R.color.text_secondary, theme))
            }

            itemView.findViewById<MaterialButton>(R.id.btnAddMontant).setOnClickListener {
                showAddMontantDialog(goal)
            }

            itemView.findViewById<MaterialButton>(R.id.btnDeleteGoal).setOnClickListener {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Supprimer l'objectif")
                    .setMessage("Supprimer \"${goal.nom}\" ?")
                    .setPositiveButton("Supprimer") { _, _ ->
                        BudgetManager.supprimerObjectif(goal.id)
                        FirebaseManager.supprimerObjectif(goal.id)
                        updateGoalsDisplay()
                    }
                    .setNegativeButton("Annuler", null)
                    .show()
            }

            containerGoals.addView(itemView)
        }
    }

    private fun updateRecurrentsDisplay() {
        containerRecurrents.removeAllViews()
        val recurrents = BudgetManager.getMouvementsRecurrents()

        if (recurrents.isEmpty()) {
            tvNoRecurrence.visibility = View.VISIBLE
            return
        }

        tvNoRecurrence.visibility = View.GONE

        for (mouvement in recurrents) {
            val card = androidx.cardview.widget.CardView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = 10 }
                setCardBackgroundColor(resources.getColor(R.color.card_dark, theme))
                radius = 40f
                cardElevation = 8f
            }

            val content = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(40, 32, 40, 32)
                gravity = android.view.Gravity.CENTER_VERTICAL
            }

            val icon = TextView(this).apply {
                text = "R"
                textSize = 20f
            }

            val infos = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setPadding(24, 0, 0, 0)
            }

            val tvTitre = TextView(this).apply {
                text = mouvement.titre
                setTextColor(resources.getColor(R.color.text_primary, theme))
                textSize = 14f
            }

            val recurrenceLabel = when (mouvement.recurrenceType) {
                "mensuel" -> "Tous les ${mouvement.recurrenceJour} du mois"
                "hebdomadaire" -> "Chaque semaine"
                else -> mouvement.recurrenceType
            }
            val tvRecurrence = TextView(this).apply {
                text = "$recurrenceLabel - ${mouvement.categorie}"
                setTextColor(resources.getColor(R.color.text_secondary, theme))
                textSize = 12f
            }

            infos.addView(tvTitre)
            infos.addView(tvRecurrence)

            val tvMontant = TextView(this).apply {
                text = mouvement.montantFormate()
                setTextColor(resources.getColor(
                    if (mouvement.isRevenu()) R.color.income_green else R.color.expense_red, theme
                ))
                textSize = 14f
                setTypeface(null, android.graphics.Typeface.BOLD)
            }

            content.addView(icon)
            content.addView(infos)
            content.addView(tvMontant)

            card.addView(content)
            containerRecurrents.addView(card)
        }
    }

    private fun setupRecyclerView() {
        adapter = CategoryAdapter(BudgetManager.categories.toMutableList()) { category ->
            MaterialAlertDialogBuilder(this)
                .setTitle("Supprimer la categorie")
                .setMessage("Voulez-vous supprimer la categorie \"${category.nom}\" ?")
                .setPositiveButton("Supprimer") { _, _ ->
                    FirebaseManager.supprimerCategorie(category.nom,
                        onSuccess = {
                            BudgetManager.supprimerCategorie(category.nom)
                            Toast.makeText(this, "Categorie supprimee", Toast.LENGTH_SHORT).show()
                        },
                        onError = { error ->
                            Toast.makeText(this, error, Toast.LENGTH_SHORT).show()
                        }
                    )
                }
                .setNegativeButton("Annuler", null)
                .show()
        }

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    private fun showAddCategoryDialog() {
        val dialogView = LayoutInflater.from(this)
            .inflate(R.layout.dialog_add_category, null)

        val etNom = dialogView.findViewById<EditText>(R.id.etCategoryNom)
        val etIcon = dialogView.findViewById<EditText>(R.id.etCategoryIcon)
        etIcon.setText("*")

        MaterialAlertDialogBuilder(this)
            .setTitle("Nouvelle categorie")
            .setView(dialogView)
            .setPositiveButton("Ajouter") { _, _ ->
                val nom = etNom.text.toString().trim()
                val icon = StringUtils.filterEmojis(etIcon.text.toString().trim().ifEmpty { "*" })

                if (nom.isEmpty()) {
                    Toast.makeText(this, "Veuillez saisir un nom", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                if (BudgetManager.categories.any { it.nom.equals(nom, ignoreCase = true) }) {
                    Toast.makeText(this, "Cette categorie existe deja", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val color = predefinedColors.random()
                val category = Category(
                    nom = nom,
                    icone = icon,
                    couleur = color,
                    isDefault = false
                )

                BudgetManager.ajouterCategorie(category)
                FirebaseManager.ajouterCategorie(category,
                    onSuccess = {
                        Toast.makeText(this, "Categorie ajoutee", Toast.LENGTH_SHORT).show()
                    },
                    onError = { error ->
                        Toast.makeText(this, error, Toast.LENGTH_SHORT).show()
                    }
                )
                updateDisplay()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun setupBottomNavigation() {
        bottomNav.selectedItemId = R.id.nav_configuration

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_dashboard -> {
                    startActivity(Intent(this, DashboardActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                R.id.nav_analytics -> {
                    startActivity(Intent(this, AnalyticsActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                R.id.nav_configuration -> true
                else -> false
            }
        }
    }

    private fun updateDisplay() {
        adapter.updateCategories(BudgetManager.categories)

        switchAlerte.isChecked = BudgetManager.alerteActivee
        if (BudgetManager.seuilAlerte != -500.0) {
            etSeuilMontant.setText(String.format("%.2f", BudgetManager.seuilAlerte))
        }

        updateGoalsDisplay()
        updateRecurrentsDisplay()
    }

    override fun onBudgetUpdated() {
        runOnUiThread { updateDisplay() }
    }

    override fun onAlertTriggered(solde: Double, seuil: Double) {}

    override fun onResume() {
        super.onResume()
        bottomNav.selectedItemId = R.id.nav_configuration
        updateDisplay()
    }

    override fun onDestroy() {
        super.onDestroy()
        BudgetManager.removeListener(this)
    }
}
