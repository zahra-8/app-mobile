package com.limargent.app.firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.limargent.app.manager.BudgetManager
import com.limargent.app.model.Category
import com.limargent.app.model.MoneyMovement
import com.limargent.app.model.SavingsGoal

object FirebaseManager {

    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val db: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    private var mouvementsListener: ListenerRegistration? = null
    private var categoriesListener: ListenerRegistration? = null
    private var savingsGoalsListener: ListenerRegistration? = null

    private const val COLLECTION_MOUVEMENTS = "mouvements"
    private const val COLLECTION_CATEGORIES = "categories"
    private const val COLLECTION_USERS = "users"
    private const val COLLECTION_SAVINGS_GOALS = "savingsGoals"

    fun getCurrentUser(): FirebaseUser? = auth.currentUser

    fun isLoggedIn(): Boolean = auth.currentUser != null

    fun getUserId(): String = auth.currentUser?.uid ?: ""

    fun register(
        email: String,
        password: String,
        onSuccess: (FirebaseUser) -> Unit,
        onError: (String) -> Unit
    ) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener { result ->
                result.user?.let { user ->
                    val userData = mapOf(
                        "email" to email,
                        "createdAt" to com.google.firebase.Timestamp.now()
                    )
                    db.collection(COLLECTION_USERS).document(user.uid)
                        .set(userData)
                        .addOnSuccessListener {
                            initDefaultCategories(user.uid)
                            onSuccess(user)
                        }
                        .addOnFailureListener { e ->
                            onError(e.message ?: "erreur lors de la creation du profil")
                        }
                } ?: onError("erreur lors de l'inscription")
            }
            .addOnFailureListener { e ->
                onError(e.message ?: "Erreur lors de l'inscription")
            }
    }

    fun login(
        email: String,
        password: String,
        onSuccess: (FirebaseUser) -> Unit,
        onError: (String) -> Unit
    ) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener { result ->
                result.user?.let { onSuccess(it) }
                    ?: onError("Erreur de connexion")
            }
            .addOnFailureListener { e ->
                onError(e.message ?: "Erreur de connexion")
            }
    }

    fun logout() {
        stopListening()
        BudgetManager.clearMouvements()
        auth.signOut()
    }
    fun ajouterMouvement(
        mouvement: MoneyMovement,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val userId = getUserId()
        if (userId.isEmpty()) {
            onError("Utilisateur non connecte")
            return
        }

        mouvement.userId = userId

        db.collection(COLLECTION_MOUVEMENTS)
            .document(mouvement.id)
            .set(mouvement.toMap())
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { e ->
                onError(e.message ?: "erreur lors de l'ajout")
            }
    }

    fun supprimerMouvement(
        id: String,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        db.collection(COLLECTION_MOUVEMENTS)
            .document(id)
            .delete()
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { e ->
                onError(e.message ?: "erreur lors de la suppression")
            }
    }

    fun startListeningMouvements() {
        val userId = getUserId()
        if (userId.isEmpty()) return

        mouvementsListener?.remove()

        mouvementsListener = db.collection(COLLECTION_MOUVEMENTS)
            .whereEqualTo("userId", userId)
            .orderBy("date", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshots, error ->
                if (error != null) return@addSnapshotListener

                snapshots?.let { snapshot ->
                    val mouvements = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { MoneyMovement.fromMap(it) }
                    }
                    BudgetManager.setMouvements(mouvements)
                }
            }
    }

    private fun initDefaultCategories(userId: String) {
        val batch = db.batch()
        Category.getDefaultCategories().forEach { category ->
            val docRef = db.collection(COLLECTION_USERS)
                .document(userId)
                .collection(COLLECTION_CATEGORIES)
                .document(category.nom)
            batch.set(docRef, mapOf(
                "nom" to category.nom,
                "icone" to category.icone,
                "couleur" to category.couleur,
                "isDefault" to category.isDefault
            ))
        }
        batch.commit()
    }

    fun ajouterCategorie(
        category: Category,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val userId = getUserId()
        if (userId.isEmpty()) {
            onError("Utilisateur non connecte")
            return
        }

        db.collection(COLLECTION_USERS)
            .document(userId)
            .collection(COLLECTION_CATEGORIES)
            .document(category.nom)
            .set(mapOf(
                "nom" to category.nom,
                "icone" to category.icone,
                "couleur" to category.couleur,
                "isDefault" to category.isDefault
            ))
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { e ->
                onError(e.message ?: "Erreur lors de l'ajout de la categorie")
            }
    }

    fun supprimerCategorie(
        nom: String,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val userId = getUserId()
        if (userId.isEmpty()) return

        db.collection(COLLECTION_USERS)
            .document(userId)
            .collection(COLLECTION_CATEGORIES)
            .document(nom)
            .delete()
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { e ->
                onError(e.message ?: "Erreur lors de la suppression")
            }
    }

    fun startListeningCategories() {
        val userId = getUserId()
        if (userId.isEmpty()) return

        categoriesListener?.remove()

        categoriesListener = db.collection(COLLECTION_USERS)
            .document(userId)
            .collection(COLLECTION_CATEGORIES)
            .addSnapshotListener { snapshots, error ->
                if (error != null) return@addSnapshotListener

                snapshots?.let { snapshot ->
                    val categories = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { data ->
                            Category(
                                nom = data["nom"] as? String ?: "",
                                icone = data["icone"] as? String ?: "*",
                                couleur = data["couleur"] as? String ?: "#6C63FF",
                                isDefault = data["isDefault"] as? Boolean ?: false
                            )
                        }
                    }
                    BudgetManager.setCategories(categories)
                }
            }
    }

    fun injecterDonneesTest(
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val userId = getUserId()
        if (userId.isEmpty()) {
            onError("Utilisateur non connecte")
            return
        }

        BudgetManager.injecterDonneesTest(userId)

        val batch = db.batch()
        BudgetManager.mouvements.forEach { mouvement ->
            val docRef = db.collection(COLLECTION_MOUVEMENTS).document(mouvement.id)
            batch.set(docRef, mouvement.toMap())
        }

        batch.commit()
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { e ->
                onError(e.message ?: "Erreur lors de l'injection des donnees de test")
            }
    }

    fun stopListening() {
        mouvementsListener?.remove()
        categoriesListener?.remove()
        savingsGoalsListener?.remove()
        mouvementsListener = null
        categoriesListener = null
        savingsGoalsListener = null
    }

    fun ajouterObjectif(
        goal: SavingsGoal,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val userId = getUserId()
        if (userId.isEmpty()) {
            onError("Utilisateur non connecte")
            return
        }

        goal.userId = userId

        db.collection(COLLECTION_USERS)
            .document(userId)
            .collection(COLLECTION_SAVINGS_GOALS)
            .document(goal.id)
            .set(goal.toMap())
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { e ->
                onError(e.message ?: "Erreur lors de l'ajout de l'objectif")
            }
    }

    fun mettreAJourObjectif(
        goal: SavingsGoal,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val userId = getUserId()
        if (userId.isEmpty()) return

        db.collection(COLLECTION_USERS)
            .document(userId)
            .collection(COLLECTION_SAVINGS_GOALS)
            .document(goal.id)
            .set(goal.toMap())
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { e ->
                onError(e.message ?: "Erreur lors de la mise a jour")
            }
    }

    fun supprimerObjectif(
        id: String,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val userId = getUserId()
        if (userId.isEmpty()) return

        db.collection(COLLECTION_USERS)
            .document(userId)
            .collection(COLLECTION_SAVINGS_GOALS)
            .document(id)
            .delete()
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { e ->
                onError(e.message ?: "Erreur lors de la suppression")
            }
    }

    fun startListeningSavingsGoals() {
        val userId = getUserId()
        if (userId.isEmpty()) return

        savingsGoalsListener?.remove()

        savingsGoalsListener = db.collection(COLLECTION_USERS)
            .document(userId)
            .collection(COLLECTION_SAVINGS_GOALS)
            .addSnapshotListener { snapshots, error ->
                if (error != null) return@addSnapshotListener

                snapshots?.let { snapshot ->
                    val goals = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { SavingsGoal.fromMap(it) }
                    }
                    BudgetManager.setSavingsGoals(goals)
                }
            }
    }

    fun sauvegarderParametresAlerte(
        seuil: Double,
        active: Boolean,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val userId = getUserId()
        if (userId.isEmpty()) return

        db.collection(COLLECTION_USERS)
            .document(userId)
            .update(mapOf(
                "seuilAlerte" to seuil,
                "alerteActivee" to active
            ))
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener {
                db.collection(COLLECTION_USERS)
                    .document(userId)
                    .set(mapOf(
                        "seuilAlerte" to seuil,
                        "alerteActivee" to active
                    ), com.google.firebase.firestore.SetOptions.merge())
                    .addOnSuccessListener { onSuccess() }
                    .addOnFailureListener { e2 ->
                        onError(e2.message ?: "Erreur")
                    }
            }
    }

    fun chargerParametresAlerte() {
        val userId = getUserId()
        if (userId.isEmpty()) return

        db.collection(COLLECTION_USERS)
            .document(userId)
            .get()
            .addOnSuccessListener { doc ->
                doc.data?.let { data ->
                    val seuil = (data["seuilAlerte"] as? Number)?.toDouble() ?: -500.0
                    val active = data["alerteActivee"] as? Boolean ?: false
                    BudgetManager.configurerAlerte(seuil, active)
                }
            }
    }
}
