package com.limargent.app.adapter
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.limargent.app.R
import com.limargent.app.manager.BudgetManager
import com.limargent.app.model.MoneyMovement

import com.google.android.material.button.MaterialButton
import com.limargent.app.utils.StringUtils

class MovementAdapter(
    private var mouvements: MutableList<MoneyMovement>,
    private val onDeleteClick: (MoneyMovement) -> Unit
) : RecyclerView.Adapter<MovementAdapter.MovementViewHolder>() {

    class MovementViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvIcon: TextView = itemView.findViewById(R.id.tvMovementIcon)
        val tvTitre: TextView = itemView.findViewById(R.id.tvMovementTitre)
        val tvCategorie: TextView = itemView.findViewById(R.id.tvMovementCategorie)
        val tvDate: TextView = itemView.findViewById(R.id.tvMovementDate)
        val tvMontant: TextView = itemView.findViewById(R.id.tvMovementMontant)
        val btnDelete: MaterialButton = itemView.findViewById(R.id.btnDeleteMovement)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovementViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_movement, parent, false)
        return MovementViewHolder(view)
    }

    override fun onBindViewHolder(holder: MovementViewHolder, position: Int) {
        val movement = mouvements[position]

        val category = BudgetManager.getCategorieByNom(movement.categorie)
        holder.tvIcon.text = StringUtils.filterEmojis(category?.icone ?: "*")

        holder.tvTitre.text = movement.titre
        holder.tvCategorie.text = movement.categorie
        holder.tvDate.text = movement.dateFormatee()

        holder.tvMontant.text = movement.montantFormate()
        if (movement.isRevenu()) {
            holder.tvMontant.setTextColor(Color.parseColor("#4CAF50"))
        } else {
            holder.tvMontant.setTextColor(Color.parseColor("#FF5252"))
        }

        holder.btnDelete.setOnClickListener {
            onDeleteClick(movement)
        }
    }

    override fun getItemCount(): Int = mouvements.size

    fun updateData(newData: List<MoneyMovement>) {
        mouvements.clear()
        mouvements.addAll(newData)
        notifyDataSetChanged()
    }
}
