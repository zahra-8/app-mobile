package com.limargent.app.utils

object StringUtils {
    /**
     *supprime les emojis et caractères non-ascii
     *nettoie les espaces 
     */
    fun filterEmojis(input: String, fallback: String = "*"): String {
        val filtered = input.filter { it.code in 0..127 }.trim()
        return if (filtered.isEmpty()) fallback else filtered
    }
}
