package com.limargent.app.model
import com.google.firebase.Timestamp
import java.util.Date
import java.util.UUID

data class SavingsGoal(
    var id:String=UUID.randomUUID().toString(),
    var nom:String="",
    var montantCible: Double=0.0,
    var montantActuel: Double=0.0,
    var icone:String="*",
    var dateCreation: Date=Date(),
    var dateEcheance: Date?=null,
    var userId:String=""
) {
    fun progression():Int {
        if (montantCible<=0) return 0
        return (montantActuel/montantCible*100).toInt().coerceIn(0, 100)
    }

    fun isAtteint():Boolean=montantActuel >= montantCible

    fun montantRestant(): Double {
        val remaining=montantCible-montantActuel
        return if (remaining>0) remaining else 0.0
    }

    fun toMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "nom" to nom,
            "montantCible" to montantCible,
            "montantActuel" to montantActuel,
            "icone" to icone,
            "dateCreation" to Timestamp(dateCreation),
            "dateEcheance" to dateEcheance?.let { Timestamp(it) },
            "userId" to userId
        )
    }

    companion object {
        fun fromMap(map: Map<String, Any?>): SavingsGoal {
            return SavingsGoal(
                id = map["id"] as? String ?: UUID.randomUUID().toString(),
                nom = map["nom"] as? String ?: "",
                montantCible = (map["montantCible"] as? Number)?.toDouble()?:0.0,
                montantActuel = (map["montantActuel"] as? Number)?.toDouble() ?: 0.0,
                icone = map["icone"] as? String ?: "*",
                dateCreation = (map["dateCreation"] as? Timestamp)?.toDate() ?:Date(),
                dateEcheance = (map["dateEcheance"] as? Timestamp)?.toDate(),
                userId = map["userId"] as? String ?: ""
            )
        }
    }
}
