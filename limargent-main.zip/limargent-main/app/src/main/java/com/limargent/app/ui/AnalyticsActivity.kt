package com.limargent.app.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.limargent.app.R
import com.limargent.app.manager.BudgetManager
import com.limargent.app.view.PieChartView

class AnalyticsActivity : AppCompatActivity(), BudgetManager.BudgetUpdateListener {

    private lateinit var pieChart: PieChartView
    private lateinit var legendContainer: LinearLayout
    private lateinit var tvTotalDepenses: TextView
    private lateinit var tvTotalRevenus: TextView
    private lateinit var tvSelectedInfo: TextView
    private lateinit var tvEmptyAnalytics: TextView
    private lateinit var bottomNav: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_analytics)

        initViews()
        setupBottomNavigation()
        setupPieChart()

        BudgetManager.addListener(this)
        updateDisplay()
    }

    private fun initViews() {
        pieChart = findViewById(R.id.pieChartView)
        legendContainer = findViewById(R.id.legendContainer)
        tvTotalDepenses = findViewById(R.id.tvAnalyticsTotalDepenses)
        tvTotalRevenus = findViewById(R.id.tvAnalyticsTotalRevenus)
        tvSelectedInfo = findViewById(R.id.tvSelectedCategoryInfo)
        tvEmptyAnalytics = findViewById(R.id.tvEmptyAnalytics)
        bottomNav = findViewById(R.id.bottomNavigation)
    }

    private fun setupPieChart() {
        pieChart.onSliceSelected = { slice, _ ->
            if (slice != null) {
                val total = BudgetManager.totalDepenses()
                val percentage = if (total > 0) (slice.value / total * 100) else 0.0
                tvSelectedInfo.text = String.format(
                    "%s : %.2f EUR (%.1f%%)",
                    slice.label, slice.value, percentage
                )
                tvSelectedInfo.visibility = View.VISIBLE
            } else {
                tvSelectedInfo.visibility = View.GONE
            }
        }
    }

    private fun setupBottomNavigation() {
        bottomNav.selectedItemId = R.id.nav_analytics

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_dashboard -> {
                    startActivity(Intent(this, DashboardActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                R.id.nav_analytics -> true
                R.id.nav_configuration -> {
                    startActivity(Intent(this, ConfigurationActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                else -> false
            }
        }
    }

    private fun updateDisplay() {
        val ventilation = BudgetManager.ventilationParCategorie()
        val totalDepenses = BudgetManager.totalDepenses()
        val totalRevenus = BudgetManager.totalRevenus()

        tvTotalDepenses.text = String.format("Depenses totales : %.2f EUR", totalDepenses)
        tvTotalRevenus.text = String.format("Revenus totaux : %.2f EUR", totalRevenus)

        if (ventilation.isEmpty()) {
            pieChart.visibility = View.GONE
            tvEmptyAnalytics.visibility = View.VISIBLE
            legendContainer.removeAllViews()
            return
        }

        pieChart.visibility = View.VISIBLE
        tvEmptyAnalytics.visibility = View.GONE

        val categoryColors = mapOf(
            "Revenus" to "#4CAF50",
            "Logement" to "#FF5722",
            "Alimentation" to "#FF9800",
            "Transport" to "#2196F3",
            "Sante" to "#E91E63",
            "Loisirs" to "#9C27B0",
            "Shopping" to "#00BCD4",
            "Education" to "#3F51B5",
            "Epargne" to "#009688",
            "Autres" to "#607D8B"
        )

        val defaultColors = listOf(
            "#FF6384", "#36A2EB", "#FFCE56", "#4BC0C0",
            "#9966FF", "#FF9F40", "#C9CBCF", "#7BC8A4"
        )

        var colorIndex = 0
        val slices = ventilation.map { (categorie, montant) ->
            val color = categoryColors[categorie]
                ?: defaultColors[colorIndex++ % defaultColors.size]
            PieChartView.PieSlice(
                label = categorie,
                value = montant,
                color = Color.parseColor(color)
            )
        }

        pieChart.setData(slices)

        legendContainer.removeAllViews()
        colorIndex = 0

        ventilation.forEach { (categorie, montant) ->
            val category = BudgetManager.getCategorieByNom(categorie)
            val color = categoryColors[categorie]
                ?: defaultColors[colorIndex++ % defaultColors.size]
            val percentage = if (totalDepenses > 0) (montant / totalDepenses * 100) else 0.0

            val legendItem = layoutInflater.inflate(R.layout.item_legend, legendContainer, false)

            val viewColor = legendItem.findViewById<View>(R.id.viewLegendColor)
            val tvLabel = legendItem.findViewById<TextView>(R.id.tvLegendLabel)
            val tvValue = legendItem.findViewById<TextView>(R.id.tvLegendValue)
            val tvPercentage = legendItem.findViewById<TextView>(R.id.tvLegendPercentage)

            viewColor.setBackgroundColor(Color.parseColor(color))
            tvLabel.text = "${category?.icone ?: "*"} $categorie"
            tvValue.text = String.format("%.2f EUR", montant)
            tvPercentage.text = String.format("%.1f%%", percentage)

            legendContainer.addView(legendItem)
        }
    }

    override fun onBudgetUpdated() {
        runOnUiThread { updateDisplay() }
    }

    override fun onAlertTriggered(solde: Double, seuil: Double) {}

    override fun onResume() {
        super.onResume()
        bottomNav.selectedItemId = R.id.nav_analytics
        updateDisplay()
    }

    override fun onDestroy() {
        super.onDestroy()
        BudgetManager.removeListener(this)
    }
}
