package com.limargent.app.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.limargent.app.R
import com.limargent.app.model.Category

class CategoryAdapter(
    private var categories: MutableList<Category>,
    private val onDeleteClick: (Category) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder>() {

    class CategoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvIcon: TextView = itemView.findViewById(R.id.tvCategoryIcon)
        val tvNom: TextView = itemView.findViewById(R.id.tvCategoryNom)
        val viewColor: View = itemView.findViewById(R.id.viewCategoryColor)
        val tvDefault: TextView = itemView.findViewById(R.id.tvCategoryDefault)
        val btnDelete: ImageButton = itemView.findViewById(R.id.btnDeleteCategory)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_category, parent, false)
        return CategoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
        val category = categories[position]

        holder.tvIcon.text = category.icone
        holder.tvNom.text = category.nom

        try {
            holder.viewColor.setBackgroundColor(Color.parseColor(category.couleur))
        } catch (e: Exception) {
            holder.viewColor.setBackgroundColor(Color.GRAY)
        }

        holder.tvDefault.visibility = if (category.isDefault) View.VISIBLE else View.GONE
        holder.btnDelete.visibility = if (category.isDefault) View.GONE else View.VISIBLE
        holder.btnDelete.setOnClickListener {
            onDeleteClick(category)
        }
    }

    override fun getItemCount(): Int = categories.size

    fun updateCategories(newCategories: List<Category>) {
        categories.clear()
        categories.addAll(newCategories)
        notifyDataSetChanged()
    }
}
