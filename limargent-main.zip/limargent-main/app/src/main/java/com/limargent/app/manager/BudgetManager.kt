package com.limargent.app.manager

import com.limargent.app.model.Category
import com.limargent.app.model.MoneyMovement
import com.limargent.app.model.SavingsGoal
import java.util.Date
import java.util.Calendar

object BudgetManager {

    private val _mouvements = mutableListOf<MoneyMovement>()
    val mouvements: List<MoneyMovement> get() = _mouvements.toList()

    private val _categories = mutableListOf<Category>()
    val categories: List<Category> get() = _categories.toList()

    private val _savingsGoals = mutableListOf<SavingsGoal>()
    val savingsGoals: List<SavingsGoal> get() = _savingsGoals.toList()

    var seuilAlerte: Double = -500.0
    var alerteActivee: Boolean = false

    private val listeners = mutableListOf<BudgetUpdateListener>()

    interface BudgetUpdateListener {
        fun onBudgetUpdated()
        fun onAlertTriggered(solde: Double, seuil: Double)
    }

    init {
        _categories.addAll(Category.getDefaultCategories())
    }

    fun calculerSolde(): Double = _mouvements.sumOf { it.montant }

    fun totalRevenus(): Double = _mouvements.filter { it.isRevenu() }.sumOf { it.montant }

    fun calculerRevenus(): Double = totalRevenus()

    fun totalDepenses(): Double = _mouvements.filter { it.isDepense() }.sumOf { it.montantAbsolu() }

    fun calculerDepenses(): Double = totalDepenses()

    fun ventilationParCategorie(): Map<String, Double> {
        return _mouvements
            .filter { it.isDepense() }
            .groupBy { it.categorie }
            .mapValues { entry -> entry.value.sumOf { it.montantAbsolu() } }
            .toSortedMap()
    }

    fun ventilationRevenusParCategorie(): Map<String, Double> {
        return _mouvements
            .filter { it.isRevenu() }
            .groupBy { it.categorie }
            .mapValues { entry -> entry.value.sumOf { it.montant } }
            .toSortedMap()
    }

    fun pourcentagesParCategorie(): Map<String, Double> {
        val total = totalDepenses()
        if (total == 0.0) return emptyMap()
        return ventilationParCategorie().mapValues { (_, montant) -> (montant / total) * 100.0 }
    }

    fun ajouterMouvement(mouvement: MoneyMovement) {
        _mouvements.add(mouvement)
        _mouvements.sortByDescending { it.date }
        verifierAlerte()
        notifyListeners()
    }

    fun supprimerMouvement(id: String): Boolean {
        val removed = _mouvements.removeAll { it.id == id }
        if (removed) notifyListeners()
        return removed
    }

    fun mettreAJourMouvement(mouvement: MoneyMovement): Boolean {
        val index = _mouvements.indexOfFirst { it.id == mouvement.id }
        if (index != -1) {
            _mouvements[index] = mouvement
            _mouvements.sortByDescending { it.date }
            verifierAlerte()
            notifyListeners()
            return true
        }
        return false
    }

    fun setMouvements(newMouvements: List<MoneyMovement>) {
        _mouvements.clear()
        _mouvements.addAll(newMouvements)
        _mouvements.sortByDescending { it.date }
        verifierAlerte()
        notifyListeners()
    }

    fun clearMouvements() {
        _mouvements.clear()
        notifyListeners()
    }

    fun clear() {
        _mouvements.clear()
        _categories.clear()
        _savingsGoals.clear()
        _categories.addAll(Category.getDefaultCategories())
        notifyListeners()
    }

    fun ajouterCategorie(category: Category) {
        if (_categories.none { it.nom == category.nom }) {
            _categories.add(category)
        }
    }

    fun supprimerCategorie(nom: String): Boolean {
        return _categories.removeAll { it.nom == nom && !it.isDefault }
    }

    fun getCategorieNoms(): List<String> = _categories.map { it.nom }

    fun getCategorieByNom(nom: String): Category? = _categories.find { it.nom == nom }

    fun setCategories(newCategories: List<Category>) {
        _categories.clear()
        _categories.addAll(newCategories)
    }

    fun ajouterObjectif(goal: SavingsGoal) {
        _savingsGoals.add(goal)
        notifyListeners()
    }

    fun supprimerObjectif(id: String): Boolean {
        val removed = _savingsGoals.removeAll { it.id == id }
        if (removed) notifyListeners()
        return removed
    }

    fun mettreAJourObjectif(goal: SavingsGoal): Boolean {
        val index = _savingsGoals.indexOfFirst { it.id == goal.id }
        if (index != -1) {
            _savingsGoals[index] = goal
            notifyListeners()
            return true
        }
        return false
    }

    fun ajouterMontantObjectif(goalId: String, montant: Double): Boolean {
        val index = _savingsGoals.indexOfFirst { it.id == goalId }
        if (index != -1) {
            _savingsGoals[index].montantActuel += montant
            notifyListeners()
            return true
        }
        return false
    }

    fun setSavingsGoals(goals: List<SavingsGoal>) {
        _savingsGoals.clear()
        _savingsGoals.addAll(goals)
        notifyListeners()
    }

    fun verifierRecurrences(userId: String): List<MoneyMovement> {
        val today = Calendar.getInstance()
        val generated = mutableListOf<MoneyMovement>()

        val recurrents = _mouvements.filter { it.isRecurrent && it.recurrenceType.isNotEmpty() }

        for (mouvement in recurrents) {
            val mouvementCal = Calendar.getInstance().apply { time = mouvement.date }

            when (mouvement.recurrenceType) {
                "mensuel" -> {
                    val jourRecurrence = mouvement.recurrenceJour
                    if (jourRecurrence > 0) {
                        val targetCal = Calendar.getInstance().apply {
                            set(Calendar.DAY_OF_MONTH, jourRecurrence.coerceAtMost(getActualMaximum(Calendar.DAY_OF_MONTH)))
                            set(Calendar.HOUR_OF_DAY, 0)
                            set(Calendar.MINUTE, 0)
                            set(Calendar.SECOND, 0)
                        }

                        if (!targetCal.after(today)) {
                            val dejaGenere = _mouvements.any { m ->
                                m.titre == mouvement.titre &&
                                m.id != mouvement.id &&
                                !m.isRecurrent &&
                                isSameMonth(m.date, targetCal.time)
                            }

                            if (!dejaGenere) {
                                val newMouvement = MoneyMovement(
                                    titre = mouvement.titre,
                                    montant = mouvement.montant,
                                    categorie = mouvement.categorie,
                                    date = targetCal.time,
                                    userId = userId,
                                    isRecurrent = false,
                                    recurrenceType = ""
                                )
                                generated.add(newMouvement)
                            }
                        }
                    }
                }
                "hebdomadaire" -> {
                    val jourSemaine = mouvementCal.get(Calendar.DAY_OF_WEEK)
                    val targetCal = Calendar.getInstance().apply {
                        set(Calendar.DAY_OF_WEEK, jourSemaine)
                        set(Calendar.HOUR_OF_DAY, 0)
                        set(Calendar.MINUTE, 0)
                        set(Calendar.SECOND, 0)
                    }

                    if (!targetCal.after(today)) {
                        val dejaGenere = _mouvements.any { m ->
                            m.titre == mouvement.titre &&
                            m.id != mouvement.id &&
                            !m.isRecurrent &&
                            isSameWeek(m.date, targetCal.time)
                        }

                        if (!dejaGenere) {
                            val newMouvement = MoneyMovement(
                                titre = mouvement.titre,
                                montant = mouvement.montant,
                                categorie = mouvement.categorie,
                                date = targetCal.time,
                                userId = userId,
                                isRecurrent = false,
                                recurrenceType = ""
                            )
                            generated.add(newMouvement)
                        }
                    }
                }
            }
        }

        generated.forEach { ajouterMouvement(it) }
        return generated
    }

    private fun isSameMonth(date1: Date, date2: Date): Boolean {
        val cal1 = Calendar.getInstance().apply { time = date1 }
        val cal2 = Calendar.getInstance().apply { time = date2 }
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
               cal1.get(Calendar.MONTH) == cal2.get(Calendar.MONTH)
    }

    private fun isSameWeek(date1: Date, date2: Date): Boolean {
        val cal1 = Calendar.getInstance().apply { time = date1 }
        val cal2 = Calendar.getInstance().apply { time = date2 }
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
               cal1.get(Calendar.WEEK_OF_YEAR) == cal2.get(Calendar.WEEK_OF_YEAR)
    }

    fun getMouvementsRecurrents(): List<MoneyMovement> = _mouvements.filter { it.isRecurrent }

    fun filtrerParCategorie(categorie: String): List<MoneyMovement> =
        _mouvements.filter { it.categorie == categorie }

    fun filtrerParPeriode(debut: Date, fin: Date): List<MoneyMovement> =
        _mouvements.filter { it.date in debut..fin }

    fun mouvementsDuMois(): List<MoneyMovement> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        val debut = cal.time

        cal.add(Calendar.MONTH, 1)
        val fin = cal.time

        return filtrerParPeriode(debut, fin)
    }

    fun rechercherParTitre(query: String): List<MoneyMovement> =
        _mouvements.filter { it.titre.contains(query, ignoreCase = true) }

    fun configurerAlerte(seuil: Double, active: Boolean) {
        seuilAlerte = seuil
        alerteActivee = active
        verifierAlerte()
    }

    private fun verifierAlerte() {
        if (alerteActivee) {
            val solde = calculerSolde()
            if (solde <= seuilAlerte) {
                listeners.forEach { it.onAlertTriggered(solde, seuilAlerte) }
            }
        }
    }

    fun injecterDonneesTest(userId: String): List<MoneyMovement> {
        val cal = Calendar.getInstance()

        val testData = listOf(
            MoneyMovement(titre = "Salaire", montant = 2000.0, categorie = "Revenus", date = cal.time, userId = userId),
            MoneyMovement(titre = "Loyer", montant = -500.0, categorie = "Logement", date = cal.time, userId = userId),
            MoneyMovement(titre = "Courses", montant = -150.0, categorie = "Alimentation",
                date = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, -2) }.time, userId = userId),
            MoneyMovement(titre = "Essence", montant = -60.0, categorie = "Transport",
                date = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, -1) }.time, userId = userId),
            MoneyMovement(titre = "Netflix", montant = -13.49, categorie = "Loisirs",
                date = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, -3) }.time, userId = userId),
            MoneyMovement(titre = "Freelance", montant = 350.0, categorie = "Revenus",
                date = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, -5) }.time, userId = userId),
            MoneyMovement(titre = "Pharmacie", montant = -25.0, categorie = "Sante",
                date = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, -1) }.time, userId = userId),
            MoneyMovement(titre = "Vetements", montant = -45.0, categorie = "Shopping",
                date = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, -4) }.time, userId = userId),
            MoneyMovement(titre = "Livre", montant = -29.99, categorie = "Education",
                date = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, -6) }.time, userId = userId),
            MoneyMovement(titre = "Epargne", montant = -200.0, categorie = "Epargne", date = cal.time, userId = userId)
        )

        testData.forEach { ajouterMouvement(it) }
        return testData
    }

    fun addListener(listener: BudgetUpdateListener) {
        listeners.add(listener)
    }

    fun removeListener(listener: BudgetUpdateListener) {
        listeners.remove(listener)
    }

    private fun notifyListeners() {
        listeners.forEach { it.onBudgetUpdated() }
    }
}
