package com.limargent.app.view

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class PieChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    data class PieSlice(
        val label: String,
        val value: Double,
        val color: Int,
        val icon: String = ""
    )

    private val slicePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#1A1A2E")
        strokeWidth = 3f
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 36f
        textAlign = Paint.Align.CENTER
    }

    private val centerTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 48f
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val centerSubTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#B0B0B0")
        textSize = 32f
        textAlign = Paint.Align.CENTER
    }

    private val selectedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = 4f
    }

    private var slices = listOf<PieSlice>()
    private var animatedAngles = floatArrayOf()
    private var totalValue = 0.0
    private var selectedIndex = -1
    private var animationProgress = 0f

    private val chartRect = RectF()
    private val selectedRect = RectF()

    private var centerX = 0f
    private var centerY = 0f
    private var radius = 0f

    var onSliceSelected: ((PieSlice?, Int) -> Unit)? = null

    fun setData(newSlices: List<PieSlice>) {
        slices = newSlices
        totalValue = slices.sumOf { it.value }
        animatedAngles = FloatArray(slices.size)
        selectedIndex = -1

        val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1200
            interpolator = DecelerateInterpolator(2f)
            addUpdateListener { animation ->
                animationProgress = animation.animatedValue as Float
                invalidate()
            }
        }
        animator.start()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)

        val padding = 60f
        val size = min(w, h).toFloat() - padding * 2
        radius = size / 2

        centerX = w / 2f
        centerY = h / 2f

        chartRect.set(
            centerX - radius,
            centerY - radius,
            centerX + radius,
            centerY + radius
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (slices.isEmpty()) {
            drawEmptyState(canvas)
            return
        }

        var startAngle = -90f

        slices.forEachIndexed { index, slice ->
            val sweepAngle = ((slice.value / totalValue) * 360f * animationProgress).toFloat()
            animatedAngles[index] = sweepAngle

            // selected slice = slightly larger
            val isSelected = index == selectedIndex
            val drawRect = if (isSelected) {
                val offset = 16f
                val midAngle = Math.toRadians((startAngle + sweepAngle / 2).toDouble())
                val dx = (cos(midAngle) * offset).toFloat()
                val dy = (sin(midAngle) * offset).toFloat()
                RectF(
                    chartRect.left + dx,
                    chartRect.top + dy,
                    chartRect.right + dx,
                    chartRect.bottom + dy
                )
            } else {
                chartRect
            }

            // draw the slice
            slicePaint.color = slice.color
            if (isSelected) {
                slicePaint.alpha = 255
            } else {
                slicePaint.alpha = if (selectedIndex == -1) 230 else 140
            }
            canvas.drawArc(drawRect, startAngle, sweepAngle, true, slicePaint)
            canvas.drawArc(drawRect, startAngle, sweepAngle, true, strokePaint)

            // show percentage on slice if large enough
            if (sweepAngle > 20f && animationProgress > 0.8f) {
                val midAngle = Math.toRadians((startAngle + sweepAngle / 2).toDouble())
                val labelRadius = radius * 0.65f
                val labelX = centerX + (cos(midAngle) * labelRadius).toFloat()
                val labelY = centerY + (sin(midAngle) * labelRadius).toFloat()

                val percentage = (slice.value / totalValue * 100).toInt()
                textPaint.textSize = if (sweepAngle > 40f) 34f else 26f
                canvas.drawText("$percentage%", labelX, labelY + 12f, textPaint)
            }

            startAngle += sweepAngle
        }

        // donut hole
        val holeRadius = radius * 0.38f
        val holePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1A1A2E")
        }
        canvas.drawCircle(centerX, centerY, holeRadius, holePaint)

        // center text
        if (animationProgress > 0.5f) {
            if (selectedIndex >= 0 && selectedIndex < slices.size) {
                val slice = slices[selectedIndex]
                val percentage = (slice.value / totalValue * 100).toInt()
                centerTextPaint.textSize = 42f
                canvas.drawText("$percentage%", centerX, centerY - 8f, centerTextPaint)
                centerSubTextPaint.textSize = 26f
                canvas.drawText(slice.label, centerX, centerY + 32f, centerSubTextPaint)
            } else {
                centerTextPaint.textSize = 38f
                canvas.drawText(
                    String.format("%.0f EUR", totalValue),
                    centerX, centerY - 8f, centerTextPaint
                )
                centerSubTextPaint.textSize = 24f
                canvas.drawText("Total", centerX, centerY + 30f, centerSubTextPaint)
            }
        }
    }

    private fun drawEmptyState(canvas: Canvas) {
        val emptyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#2A2A4A")
        }
        canvas.drawCircle(centerX, centerY, radius, emptyPaint)

        val holeRadius = radius * 0.38f
        val holePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1A1A2E")
        }
        canvas.drawCircle(centerX, centerY, holeRadius, holePaint)

        centerTextPaint.textSize = 36f
        canvas.drawText("Aucune donnee", centerX, centerY, centerTextPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            val touchX = event.x - centerX
            val touchY = event.y - centerY
            val distance = sqrt((touchX * touchX + touchY * touchY).toDouble())

            val holeRadius = radius * 0.38f

            if (distance > holeRadius && distance < radius + 20) {
                // Calculer l'angle du toucher
                var touchAngle = Math.toDegrees(
                    atan2(touchY.toDouble(), touchX.toDouble())
                ).toFloat()
                touchAngle = (touchAngle + 90f + 360f) % 360f

                // find the touched slice
                var currentAngle = 0f
                for (i in slices.indices) {
                    val sweepAngle = ((slices[i].value / totalValue) * 360f).toFloat()
                    if (touchAngle >= currentAngle && touchAngle < currentAngle + sweepAngle) {
                        selectedIndex = if (selectedIndex == i) -1 else i
                        onSliceSelected?.invoke(
                            if (selectedIndex >= 0) slices[selectedIndex] else null,
                            selectedIndex
                        )
                        invalidate()
                        performClick()
                        return true
                    }
                    currentAngle += sweepAngle
                }
            } else {
                selectedIndex = -1
                onSliceSelected?.invoke(null, -1)
                invalidate()
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
