package com.limargent.app.model

data class Category(
    var nom: String = "",
    var icone: String = "*",
    var couleur: String = "#6C63FF",
    var isDefault: Boolean = false
) {
    companion object {
        fun getDefaultCategories(): List<Category> {
            return listOf(
                Category("Revenus", "+", "#4CAF50", true),
                Category("Logement", "H", "#FF5722", true),
                Category("Alimentation", "A", "#FF9800", true),
                Category("Transport", "T", "#2196F3", true),
                Category("Sante", "S", "#E91E63", true),
                Category("Loisirs", "L", "#9C27B0", true),
                Category("Shopping", "Sh", "#00BCD4", true),
                Category("Education", "E", "#3F51B5", true),
                Category("Epargne", "Ep", "#009688", true),
                Category("Autres", "?", "#607D8B", true)
            )
        }
    }
}
