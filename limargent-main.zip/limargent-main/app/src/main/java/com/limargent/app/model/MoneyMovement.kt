package com.limargent.app.model
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class MoneyMovement(
    @DocumentId
    var id: String = UUID.randomUUID().toString(),
    var titre: String = "",
    var montant: Double = 0.0,
    var categorie: String = "",
    var date: Date = Date(),
    var userId: String = "",
    var isRecurrent: Boolean = false,
    var recurrenceType: String = "",
    var recurrenceJour: Int = 0
) {
    constructor():this(
        id = UUID.randomUUID().toString(),
        titre = "",
        montant = 0.0,
        categorie = "",
        date = Date(),
        userId = "",
        isRecurrent = false,
        recurrenceType = "",
        recurrenceJour = 0
    )
    fun isDepense(): Boolean=montant < 0
    fun isRevenu(): Boolean=montant > 0
    fun montantAbsolu(): Double=kotlin.math.abs(montant)

    fun dateFormatee():String {
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.FRANCE)
        return sdf.format(date)
    }

    fun montantFormate():String {
        return if (montant >= 0) {
            String.format(Locale.FRANCE, "+%.2f EUR", montant)
        } else {
            String.format(Locale.FRANCE, "%.2f EUR", montant)
        }
    }

    fun toMap():Map<String, Any?> {
        return mapOf(
            "id" to id,
            "titre" to titre,
            "montant" to montant,
            "categorie" to categorie,
            "date" to Timestamp(date),
            "userId" to userId,
            "isRecurrent" to isRecurrent,
            "recurrenceType" to recurrenceType,
            "recurrenceJour" to recurrenceJour
        )
    }

    companion object{
        fun fromMap(map: Map<String, Any?>): MoneyMovement {
            return MoneyMovement(
                id = map["id"] as? String ?: UUID.randomUUID().toString(),
                titre = map["titre"] as? String ?: "",
                montant = (map["montant"] as? Number)?.toDouble() ?: 0.0,
                categorie = map["categorie"] as? String ?: "",
                date = (map["date"] as? Timestamp)?.toDate() ?: Date(),
                userId = map["userId"] as? String ?: "",
                isRecurrent = map["isRecurrent"] as? Boolean ?: false,
                recurrenceType = map["recurrenceType"] as? String ?: "",
                recurrenceJour = (map["recurrenceJour"] as? Number)?.toInt() ?: 0
            )
        }
    }
}
