package com.limargent.app.ui

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.limargent.app.R
import com.limargent.app.firebase.FirebaseManager
import com.limargent.app.manager.BudgetManager
import com.limargent.app.model.MoneyMovement
import java.util.*

class AddMovementActivity : AppCompatActivity() {

    private lateinit var tvMontantDisplay: TextView
    private lateinit var etTitre: EditText
    private lateinit var switchRevenu: Switch
    private lateinit var tvTypeDepense: TextView
    private lateinit var tvTypeRevenu: TextView
    private lateinit var spinnerCategorie: Spinner
    private lateinit var tvSelectedDate: TextView
    private lateinit var btnValider: MaterialButton

    private lateinit var switchRecurrence: Switch
    private lateinit var layoutRecurrenceOptions: View
    private lateinit var spinnerRecurrence: Spinner
    private lateinit var layoutJourMois: View
    private lateinit var spinnerJourMois: Spinner

    private var montantString = ""
    private val calendar = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_movement)

        initViews()
        setupNumericKeypad()
        setupSwitch()
        setupCategorySpinner()
        setupDatePicker()
        setupRecurrence()
        setupValidation()
        setupBackButton()

        updateDateDisplay()
    }

    private fun initViews() {
        tvMontantDisplay = findViewById(R.id.tvMontantDisplay)
        etTitre = findViewById(R.id.etTitre)
        switchRevenu = findViewById(R.id.switchRevenu)
        tvTypeDepense = findViewById(R.id.tvTypeDepense)
        tvTypeRevenu = findViewById(R.id.tvTypeRevenu)
        spinnerCategorie = findViewById(R.id.spinnerCategorie)
        tvSelectedDate = findViewById(R.id.tvSelectedDate)
        btnValider = findViewById(R.id.btnValider)

        switchRecurrence = findViewById(R.id.switchRecurrence)
        layoutRecurrenceOptions = findViewById(R.id.layoutRecurrenceOptions)
        spinnerRecurrence = findViewById(R.id.spinnerRecurrence)
        layoutJourMois = findViewById(R.id.layoutJourMois)
        spinnerJourMois = findViewById(R.id.spinnerJourMois)
    }

    private fun setupNumericKeypad() {
        val numberButtons = mapOf(
            R.id.btn0 to "0",
            R.id.btn1 to "1",
            R.id.btn2 to "2",
            R.id.btn3 to "3",
            R.id.btn4 to "4",
            R.id.btn5 to "5",
            R.id.btn6 to "6",
            R.id.btn7 to "7",
            R.id.btn8 to "8",
            R.id.btn9 to "9"
        )

        numberButtons.forEach { (buttonId, digit) ->
            findViewById<MaterialButton>(buttonId).setOnClickListener {
                onDigitPressed(digit)
            }
        }

        findViewById<MaterialButton>(R.id.btnComma).setOnClickListener {
            onCommaPressed()
        }

        findViewById<MaterialButton>(R.id.btnDelete).setOnClickListener {
            onDeletePressed()
        }

        findViewById<MaterialButton>(R.id.btnDelete).setOnLongClickListener {
            montantString = ""
            updateMontantDisplay()
            true
        }
    }

    private fun onDigitPressed(digit: String) {
        if (montantString.contains(",")) {
            val decimals = montantString.substringAfter(",")
            if (decimals.length >= 2) return
        }
        if (montantString.replace(",", "").length >= 10) return
        if (montantString == "0" && digit == "0") return
        if (montantString == "0" && digit != "0" && !montantString.contains(",")) {
            montantString = digit
        } else {
            montantString += digit
        }
        updateMontantDisplay()
    }

    private fun onCommaPressed() {
        if (montantString.contains(",")) return
        if (montantString.isEmpty()) montantString = "0"
        montantString += ","
        updateMontantDisplay()
    }

    private fun onDeletePressed() {
        if (montantString.isNotEmpty()) {
            montantString = montantString.dropLast(1)
            updateMontantDisplay()
        }
    }

    private fun updateMontantDisplay() {
        tvMontantDisplay.text = if (montantString.isEmpty()) "0,00" else montantString
    }

    private fun setupSwitch() {
        switchRevenu.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                tvTypeRevenu.setTextColor(resources.getColor(R.color.income_green, theme))
                tvTypeRevenu.textSize = 16f
                tvTypeDepense.setTextColor(resources.getColor(R.color.text_secondary, theme))
                tvMontantDisplay.setTextColor(resources.getColor(R.color.income_green, theme))
            } else {
                tvTypeDepense.setTextColor(resources.getColor(R.color.expense_red, theme))
                tvTypeRevenu.setTextColor(resources.getColor(R.color.text_secondary, theme))
                tvTypeRevenu.textSize = 16f
                tvMontantDisplay.setTextColor(resources.getColor(R.color.expense_red, theme))
            }
        }
        tvMontantDisplay.setTextColor(resources.getColor(R.color.expense_red, theme))
    }

    private fun setupCategorySpinner() {
        val categories = BudgetManager.categories.map { it.nom }
        val catAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        catAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCategorie.adapter = catAdapter
    }

    private fun setupDatePicker() {
        val dateClickListener = {
            DatePickerDialog(this, { _, year, month, day ->
                calendar.set(year, month, day)
                updateDateDisplay()
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
        }

        findViewById<View>(R.id.btnSelectDate).setOnClickListener { dateClickListener() }
        tvSelectedDate.setOnClickListener { dateClickListener() }
    }

    private fun updateDateDisplay() {
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val month = calendar.get(Calendar.MONTH) + 1
        val year = calendar.get(Calendar.YEAR)
        tvSelectedDate.text = "$day/$month/$year"
    }

    private fun setupRecurrence() {
        val recurrenceTypes = listOf("Mensuel", "Hebdomadaire")
        val recurrenceAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, recurrenceTypes)
        recurrenceAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerRecurrence.adapter = recurrenceAdapter

        val jours = (1..31).map { it.toString() }
        val jourAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, jours)
        jourAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerJourMois.adapter = jourAdapter

        val currentDay = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
        spinnerJourMois.setSelection(currentDay - 1)

        switchRecurrence.setOnCheckedChangeListener { _, isChecked ->
            layoutRecurrenceOptions.visibility = if (isChecked) View.VISIBLE else View.GONE
        }

        spinnerRecurrence.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                layoutJourMois.visibility = if (position == 0) View.VISIBLE else View.GONE
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setupValidation() {
        btnValider.setOnClickListener {
            val titre = etTitre.text.toString().trim()

            val montantParsed = montantString.replace(",", ".").toDoubleOrNull()
            if (montantParsed == null || montantParsed <= 0) {
                Toast.makeText(this, "Veuillez entrer un montant valide", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (titre.isEmpty()) {
                Toast.makeText(this, "Veuillez saisir le libelle de l'operation", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val montant = if (switchRevenu.isChecked) montantParsed else -montantParsed
            val categorie = spinnerCategorie.selectedItem?.toString() ?: "Autres"

            val isRecurrent = switchRecurrence.isChecked
            var recurrenceType = ""
            var recurrenceJour = 0

            if (isRecurrent) {
                recurrenceType = when (spinnerRecurrence.selectedItemPosition) {
                    0 -> "mensuel"
                    1 -> "hebdomadaire"
                    else -> ""
                }
                if (recurrenceType == "mensuel") {
                    recurrenceJour = spinnerJourMois.selectedItemPosition + 1
                }
            }

            val mouvement = MoneyMovement(
                titre = titre,
                montant = montant,
                categorie = categorie,
                date = calendar.time,
                userId = FirebaseManager.getCurrentUser()?.uid ?: "",
                isRecurrent = isRecurrent,
                recurrenceType = recurrenceType,
                recurrenceJour = recurrenceJour
            )

            BudgetManager.ajouterMouvement(mouvement)
            FirebaseManager.ajouterMouvement(mouvement)

            val message = if (isRecurrent) "Operation recurrente ajoutee" else "Operation ajoutee"
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun setupBackButton() {
        findViewById<ImageButton>(R.id.btnBack).setOnClickListener {
            finish()
        }
    }
}
