package com.limargent.app.ui

import android.Manifest
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.limargent.app.R
import com.limargent.app.adapter.MovementAdapter
import com.limargent.app.firebase.FirebaseManager
import com.limargent.app.manager.BudgetManager
import com.limargent.app.manager.NotificationHelper
import com.limargent.app.model.Category
import com.limargent.app.model.MoneyMovement
import java.text.NumberFormat
import java.util.*

class DashboardActivity : AppCompatActivity(), BudgetManager.BudgetUpdateListener {

    private lateinit var tvWelcome: TextView
    private lateinit var tvSolde: TextView
    private lateinit var tvRevenus: TextView
    private lateinit var tvDepenses: TextView
    private lateinit var tvEmptyState: TextView
    private lateinit var tvMovementCount: TextView
    private lateinit var tvAlertBanner: TextView
    private lateinit var tvActiveFilter: TextView
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MovementAdapter
    private lateinit var bottomNavigation: BottomNavigationView
    private lateinit var fab: FloatingActionButton

    private lateinit var searchBarLayout: View
    private lateinit var etSearch: EditText
    private lateinit var chipAllTime: Chip
    private lateinit var chipThisMonth: Chip
    private lateinit var chipRevenus: Chip
    private lateinit var chipDepenses: Chip
    private lateinit var chipByCategory: Chip

    private var currentFilter = FilterMode.ALL
    private var currentSearchQuery = ""
    private var currentCategoryFilter: String? = null
    private var isSearchVisible = false

    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale.FRANCE)

    companion object {
        private const val TAG = "DashboardActivity"
    }

    enum class FilterMode {
        ALL, THIS_MONTH, REVENUS_ONLY, DEPENSES_ONLY, BY_CATEGORY
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        initViews()
        setupRecyclerView()
        setupBottomNavigation()
        setupFAB()
        setupSearch()
        setupFilters()
        setupToolbarButtons()

        NotificationHelper.createNotificationChannel(this)
        requestNotificationPermission()

        BudgetManager.addListener(this)
        loadFirebaseData()

        val userName = FirebaseManager.getCurrentUser()?.email?.substringBefore("@") ?: "Utilisateur"
        tvWelcome.text = "Bonjour, $userName"
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    1001
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        BudgetManager.removeListener(this)
    }

    private fun initViews() {
        tvWelcome = findViewById(R.id.tvWelcome)
        tvSolde = findViewById(R.id.tvSolde)
        tvRevenus = findViewById(R.id.tvRevenus)
        tvDepenses = findViewById(R.id.tvDepenses)
        tvEmptyState = findViewById(R.id.tvEmptyState)
        tvMovementCount = findViewById(R.id.tvMovementCount)
        tvAlertBanner = findViewById(R.id.tvAlertBanner)
        tvActiveFilter = findViewById(R.id.tvActiveFilter)
        recyclerView = findViewById(R.id.recyclerViewMouvements)
        bottomNavigation = findViewById(R.id.bottomNavigation)
        fab = findViewById(R.id.fabAddMovement)

        searchBarLayout = findViewById(R.id.searchBarLayout)
        etSearch = findViewById(R.id.etSearch)
        chipAllTime = findViewById(R.id.chipAllTime)
        chipThisMonth = findViewById(R.id.chipThisMonth)
        chipRevenus = findViewById(R.id.chipRevenus)
        chipDepenses = findViewById(R.id.chipDepenses)
        chipByCategory = findViewById(R.id.chipByCategory)
    }

    private fun setupRecyclerView() {
        adapter = MovementAdapter(
            mouvements = mutableListOf(),
            onDeleteClick = { mouvement ->
                MaterialAlertDialogBuilder(this)
                    .setTitle("Supprimer")
                    .setMessage("Supprimer \"${mouvement.titre}\" ?")
                    .setPositiveButton("Supprimer") { _, _ ->
                        BudgetManager.supprimerMouvement(mouvement.id)
                        FirebaseManager.supprimerMouvement(mouvement.id)
                    }
                    .setNegativeButton("Annuler", null)
                    .show()
            }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    private fun setupBottomNavigation() {
        bottomNavigation.selectedItemId = R.id.nav_dashboard
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_dashboard -> true
                R.id.nav_analytics -> {
                    startActivity(Intent(this, AnalyticsActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                R.id.nav_configuration -> {
                    startActivity(Intent(this, ConfigurationActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                else -> false
            }
        }
    }

    private fun setupFAB() {
        fab.setOnClickListener {
            startActivity(Intent(this, AddMovementActivity::class.java))
        }
    }

    private fun setupSearch() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                currentSearchQuery = s?.toString()?.trim() ?: ""
                applyFilters()
            }
        })
    }

    private fun setupFilters() {
        chipAllTime.setOnClickListener { setFilter(FilterMode.ALL) }
        chipThisMonth.setOnClickListener { setFilter(FilterMode.THIS_MONTH) }
        chipRevenus.setOnClickListener { setFilter(FilterMode.REVENUS_ONLY) }
        chipDepenses.setOnClickListener { setFilter(FilterMode.DEPENSES_ONLY) }
        chipByCategory.setOnClickListener { showCategoryFilterDialog() }
    }

    private fun setFilter(mode: FilterMode) {
        currentFilter = mode
        currentCategoryFilter = null

        chipAllTime.isChecked = mode == FilterMode.ALL
        chipThisMonth.isChecked = mode == FilterMode.THIS_MONTH
        chipRevenus.isChecked = mode == FilterMode.REVENUS_ONLY
        chipDepenses.isChecked = mode == FilterMode.DEPENSES_ONLY
        chipByCategory.isChecked = mode == FilterMode.BY_CATEGORY

        when (mode) {
            FilterMode.ALL -> tvActiveFilter.visibility = View.GONE
            FilterMode.THIS_MONTH -> {
                tvActiveFilter.text = "Filtre : Ce mois"
                tvActiveFilter.visibility = View.VISIBLE
            }
            FilterMode.REVENUS_ONLY -> {
                tvActiveFilter.text = "Filtre : Revenus"
                tvActiveFilter.visibility = View.VISIBLE
            }
            FilterMode.DEPENSES_ONLY -> {
                tvActiveFilter.text = "Filtre : Depenses"
                tvActiveFilter.visibility = View.VISIBLE
            }
            FilterMode.BY_CATEGORY -> {}
        }

        applyFilters()
    }

    private fun showCategoryFilterDialog() {
        val categories = BudgetManager.categories.map { it.nom }.toTypedArray()
        if (categories.isEmpty()) {
            Toast.makeText(this, "Aucune categorie disponible", Toast.LENGTH_SHORT).show()
            return
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Filtrer par categorie")
            .setItems(categories) { _, which ->
                currentCategoryFilter = categories[which]
                currentFilter = FilterMode.BY_CATEGORY
                chipByCategory.isChecked = true
                chipAllTime.isChecked = false
                chipThisMonth.isChecked = false
                chipRevenus.isChecked = false
                chipDepenses.isChecked = false

                tvActiveFilter.text = "Filtre : ${currentCategoryFilter}"
                tvActiveFilter.visibility = View.VISIBLE
                applyFilters()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun applyFilters() {
        var filtered = BudgetManager.mouvements.toList()

        filtered = when (currentFilter) {
            FilterMode.ALL -> filtered
            FilterMode.THIS_MONTH -> BudgetManager.mouvementsDuMois()
            FilterMode.REVENUS_ONLY -> filtered.filter { it.isRevenu() }
            FilterMode.DEPENSES_ONLY -> filtered.filter { it.isDepense() }
            FilterMode.BY_CATEGORY -> {
                currentCategoryFilter?.let { cat ->
                    BudgetManager.filtrerParCategorie(cat)
                } ?: filtered
            }
        }

        if (currentSearchQuery.isNotEmpty()) {
            filtered = filtered.filter {
                it.titre.contains(currentSearchQuery, ignoreCase = true) ||
                it.categorie.contains(currentSearchQuery, ignoreCase = true)
            }
        }

        adapter.updateData(filtered)
        tvMovementCount.text = "${filtered.size} resultat(s)"
        tvEmptyState.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
        recyclerView.visibility = if (filtered.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun setupToolbarButtons() {
        findViewById<ImageButton>(R.id.btnSearch).setOnClickListener {
            isSearchVisible = !isSearchVisible
            searchBarLayout.visibility = if (isSearchVisible) View.VISIBLE else View.GONE
            if (!isSearchVisible) {
                etSearch.text.clear()
                currentSearchQuery = ""
                setFilter(FilterMode.ALL)
            }
        }

        findViewById<ImageButton>(R.id.btnFilter).setOnClickListener {
            showFilterMenu()
        }

        findViewById<ImageButton>(R.id.btnTestData).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Donnees de test")
                .setMessage("Injecter 10 transactions de test ?")
                .setPositiveButton("Injecter") { _, _ -> injectTestData() }
                .setNegativeButton("Annuler", null)
                .show()
        }

        findViewById<ImageButton>(R.id.btnLogout).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Deconnexion")
                .setMessage("Voulez-vous vous deconnecter ?")
                .setPositiveButton("Oui") { _, _ ->
                    FirebaseManager.logout()
                    BudgetManager.clear()
                    startActivity(Intent(this, LoginActivity::class.java))
                    finish()
                }
                .setNegativeButton("Non", null)
                .show()
        }
    }

    private fun showFilterMenu() {
        val options = arrayOf(
            "Tout afficher",
            "Ce mois uniquement",
            "Revenus uniquement",
            "Depenses uniquement",
            "Par categorie..."
        )

        MaterialAlertDialogBuilder(this)
            .setTitle("Filtrer les mouvements")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> setFilter(FilterMode.ALL)
                    1 -> setFilter(FilterMode.THIS_MONTH)
                    2 -> setFilter(FilterMode.REVENUS_ONLY)
                    3 -> setFilter(FilterMode.DEPENSES_ONLY)
                    4 -> showCategoryFilterDialog()
                }
            }
            .show()
    }

    private fun showAddMovementDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_movement, null)
        val etMontant = dialogView.findViewById<EditText>(R.id.etMontant)
        val etTitre = dialogView.findViewById<EditText>(R.id.etTitre)
        val spinnerCategorie = dialogView.findViewById<Spinner>(R.id.spinnerCategorie)
        val tvDate = dialogView.findViewById<TextView>(R.id.tvSelectedDate)
        val btnDate = dialogView.findViewById<View>(R.id.btnSelectDate)
        val switchRevenu = dialogView.findViewById<Switch>(R.id.switchRevenu)

        val calendar = Calendar.getInstance()
        tvDate.text = "${calendar.get(Calendar.DAY_OF_MONTH)}/${calendar.get(Calendar.MONTH) + 1}/${calendar.get(Calendar.YEAR)}"

        val dateClickListener = View.OnClickListener {
            DatePickerDialog(this, { _, year, month, day ->
                calendar.set(year, month, day)
                tvDate.text = "$day/${month + 1}/$year"
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
        }
        btnDate?.setOnClickListener(dateClickListener)
        tvDate.setOnClickListener(dateClickListener)

        val categories = BudgetManager.categories.map { it.nom }
        val catAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        catAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCategorie.adapter = catAdapter

        MaterialAlertDialogBuilder(this)
            .setTitle("Ajouter une transaction")
            .setView(dialogView)
            .setPositiveButton("Ajouter") { _, _ ->
                val montantStr = etMontant.text.toString().trim()
                val titre = etTitre.text.toString().trim()

                if (montantStr.isEmpty() || titre.isEmpty()) {
                    Toast.makeText(this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val montantValue = montantStr.toDoubleOrNull()
                if (montantValue == null || montantValue <= 0) {
                    Toast.makeText(this, "Montant invalide", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val montant = if (switchRevenu.isChecked) montantValue else -montantValue
                val categorie = spinnerCategorie.selectedItem?.toString() ?: "Autres"

                val mouvement = MoneyMovement(
                    titre = titre,
                    montant = montant,
                    categorie = categorie,
                    date = calendar.time,
                    userId = FirebaseManager.getCurrentUser()?.uid ?: ""
                )

                BudgetManager.ajouterMouvement(mouvement)
                FirebaseManager.ajouterMouvement(mouvement)
                Toast.makeText(this, "Transaction ajoutee", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun loadFirebaseData() {
        val userId = FirebaseManager.getCurrentUser()?.uid ?: return

        FirebaseManager.startListeningCategories()
        FirebaseManager.startListeningMouvements()
        FirebaseManager.startListeningSavingsGoals()
        FirebaseManager.chargerParametresAlerte()

        val generated = BudgetManager.verifierRecurrences(userId)
        generated.forEach { mouvement ->
            FirebaseManager.ajouterMouvement(mouvement)
        }

        updateUI()
    }

    private fun injectTestData() {
        val userId = FirebaseManager.getCurrentUser()?.uid ?: return
        val testData = BudgetManager.injecterDonneesTest(userId)
        testData.forEach { mouvement ->
            FirebaseManager.ajouterMouvement(mouvement)
        }
        Toast.makeText(this, "${testData.size} transactions ajoutees", Toast.LENGTH_SHORT).show()
    }

    override fun onBudgetUpdated() {
        runOnUiThread { updateUI() }
    }

    override fun onAlertTriggered(solde: Double, seuil: Double) {
        runOnUiThread {
            tvAlertBanner.text = "Attention : Solde (${currencyFormat.format(solde)}) en dessous du seuil (${currencyFormat.format(seuil)})"
            tvAlertBanner.visibility = View.VISIBLE
        }
        NotificationHelper.sendAlertNotification(this, solde, seuil)
    }

    private fun updateUI() {
        val solde = BudgetManager.calculerSolde()
        val revenus = BudgetManager.calculerRevenus()
        val depenses = BudgetManager.calculerDepenses()

        tvSolde.text = currencyFormat.format(solde)
        tvSolde.setTextColor(resources.getColor(
            if (solde >= 0) R.color.income_green else R.color.expense_red, theme
        ))

        tvRevenus.text = "+${currencyFormat.format(revenus)}"
        tvDepenses.text = currencyFormat.format(depenses)

        if (BudgetManager.alerteActivee && solde < BudgetManager.seuilAlerte) {
            tvAlertBanner.text = "Attention : Solde en dessous du seuil (${currencyFormat.format(BudgetManager.seuilAlerte)})"
            tvAlertBanner.visibility = View.VISIBLE
        } else {
            tvAlertBanner.visibility = View.GONE
        }

        applyFilters()
    }
}
