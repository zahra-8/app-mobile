package com.limargent.app.ui
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputLayout
import com.limargent.app.R
import com.limargent.app.firebase.FirebaseManager

class LoginActivity : AppCompatActivity() {
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var tilPasswordConfirm: TextInputLayout
    private lateinit var etPasswordConfirm: EditText
    private lateinit var btnLogin: MaterialButton
    private lateinit var btnRegister: MaterialButton
    private lateinit var progressBar: ProgressBar
    private lateinit var tvError: TextView
    companion object {
        private const val TAG = "LoginActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (FirebaseManager.isLoggedIn()) {
            navigateToDashboard()
            return
        }

        setContentView(R.layout.activity_login)
        initViews()
        setupClickListeners()
    }

    private fun initViews() {
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        tilPasswordConfirm = findViewById(R.id.tilPasswordConfirm)
        etPasswordConfirm = findViewById(R.id.etPasswordConfirm)
        btnLogin = findViewById(R.id.btnLogin)
        btnRegister = findViewById(R.id.btnRegister)
        progressBar = findViewById(R.id.progressBarLogin)
        tvError = findViewById(R.id.tvLoginError)
    }
     private fun setupClickListeners() {
        btnLogin.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                showError("veuillez remplir tous les champs svp!!")
                return@setOnClickListener
            }

            setLoading(true)
            Toast.makeText(this, "Connexion en cours...", Toast.LENGTH_SHORT).show()

            FirebaseManager.login(email, password,
                onSuccess = { user ->
                    Log.d(TAG, "Connexion reussie: ${user.email}")
                    runOnUiThread {
                        setLoading(false)
                        Toast.makeText(this, "Connecte", Toast.LENGTH_SHORT).show()
                        navigateToDashboard()
                    }
                },
                onError = { error ->
                    Log.e(TAG, "erreur connexion: $error")
                    runOnUiThread {
                        setLoading(false)
                        showError(error)
                    }
                }
            )
        }

        btnRegister.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (email.isEmpty()||password.isEmpty()) { 
                showError("veuillez remplir email et mot de passe")
                return@setOnClickListener
            }

            if (password.length < 6) {
                showError("le mot de passe doit contenir au moins 6 caracteres")
                return@setOnClickListener
            }

            setLoading(true)
            Toast.makeText(this, "inscription en cours...", Toast.LENGTH_SHORT).show()

            FirebaseManager.register(email, password,
                onSuccess = { user ->
                    Log.d(TAG, "inscription reussie: ${user.email}")
                    runOnUiThread {
                        setLoading(false)
                        Toast.makeText(this, "Compte cree avec succes", Toast.LENGTH_LONG).show()
                        navigateToDashboard()
                    }
                },
                onError = { error ->
                    Log.e(TAG, "Erreur inscription: $error")
                    runOnUiThread {
                        setLoading(false)
                        showError(error)
                    }
                }
            )
        }
    }

    private fun setLoading(loading: Boolean) {
        progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        btnLogin.isEnabled = !loading
        btnRegister.isEnabled = !loading
        etEmail.isEnabled = !loading
        etPassword.isEnabled = !loading
    }

    private fun showError(message: String) {
        tvError.text = message
        tvError.visibility = View.VISIBLE
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun navigateToDashboard() {
        val intent = Intent(this, DashboardActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
