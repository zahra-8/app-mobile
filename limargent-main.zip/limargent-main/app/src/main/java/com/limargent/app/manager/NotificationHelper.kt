package com.limargent.app.manager

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.limargent.app.R
import com.limargent.app.ui.DashboardActivity
import java.text.NumberFormat
import java.util.Locale

object NotificationHelper {

    private const val CHANNEL_ID = "limargent_alerts"
    private const val CHANNEL_NAME = "Alertes de solde"
    private const val CHANNEL_DESC = "Notifications lorsque le solde descend en dessous du seuil defini"
    private const val NOTIFICATION_ID_ALERT = 1001

    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale.FRANCE)

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = CHANNEL_DESC
                enableVibration(true)
                enableLights(true)
            }

            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun sendAlertNotification(context: Context, solde: Double, seuil: Double) {
        createNotificationChannel(context)

        val intent = Intent(context, DashboardActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Alerte LimArgent")
            .setContentText("Votre solde (${currencyFormat.format(solde)}) est en dessous du seuil (${currencyFormat.format(seuil)})")
            .setStyle(NotificationCompat.BigTextStyle()
                .bigText("Votre solde actuel de ${currencyFormat.format(solde)} est descendu en dessous de votre seuil d'alerte fixe a ${currencyFormat.format(seuil)}.\n\nOuvrez l'application pour verifier vos finances."))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setVibrate(longArrayOf(0, 500, 200, 500))
            .build()

        try {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_ALERT, notification)
        } catch (e: SecurityException) {
            // permission non accordee
        }
    }
}
